Please run index.html to view the details

Head:
    The HTML <head> Tag is used to define the head portion of the document which contains information related to the document. I have used it to define the external css link and logo of the website.

Meta:
    The HTML <meta> tag defines metadata about an HTML document, including character set, description, keywords, author, and viewport settings.

Body:
    The <body> tag in HTML is used to define the main content present inside an HTML page. It is always enclosed within <HTML> tag. The <body> tag is the last child of the <html> tag. The <body> tag contains all the contents of an HTML document, such as headings, images, hyperlinks, tables, lists, paragraphs, etc.

Div:
    The HTML <div> tag defines sections in HTML documents, serving as containers styled with CSS or controlled with JavaScript. It’s easily customized using class or id attributes and can contain various content.

Favicon: 
    HTML Favicon is a small icon representing a website, appearing in the browser’s tab or bookmark bar. Defined using the <link> tag with `rel=”icon”`, it is also known as the Favorite icon. I have used it in head tag to display logo on tab.

Table:
    HTML <table> tag is utilized to create tables on a webpage. It helps in structuring and displaying data in an organized and tabular manner. It helps to render the information in rows and columns, utilizing elements like <tr>, <th>, and <td> to specify different parts of the table cells. The <tr> tag is used to define a row in an HTML table.The <tr> element contains multiple <th> or <td> elements. The <th> tag in HTML is used to set the header cell of a table.The <td> tag is used to define a standard cell in an HTML table. I have used it to display project details.

Form:
    HTML Forms utilize the <form> element as a powerful tool to collect user input through a variety of interactive controls.
    The HTML <form> comprises several elements, each serving a unique purpose. For instance, the <label> element is used to define labels for other <form> elements. The <input> element, on the other hand, is versatile and can be used to capture various types of input data such as text, password, email, and more, simply by altering its type attribute. I have used it to get the contact details from the visitor.

Images:
    The HTML <img> tag is used to embed an image in web pages by linking them. It creates a placeholder for the image, defined by attributes like src, width, height, and alt, and does not require a closing tag. I have used it to display my favorite music.

Hyperlink:
    HTML links, or hyperlinks, connect web pages and are created using the `<a>` tag with the `href` attribute. They enable users to navigate between pages or resources. Links can be text, images, or other elements, enhancing web navigation and interactivity. Users can click on links to navigate between different pages or resources. I have used it to navigate the section in the menu.

Button:
    The <button> tag creates a clickable button, permitting nested text and tags such as <i>, <b>, <strong>, <br>, <img>, offering more versatility compared to buttons made with <input>. I have used it to submit the contact details.

audio:
    The <audio> tag is an inline element that is used to embed sound files into a web page. Since the release of HTML5, audio can be added to web pages using the “audio” tag. It is a useful tag if you want to add audio such as songs, interviews, etc. on your webpage. I have used it to show my favorite music.

video:
    The <video> element in HTML allows you to embed video content directly into web pages. It supports various video formats, including MP4, WebM, and Ogg. In this guide, we’ll learn about the key features of HTML5 video. video and audio tags are introduced in HTML5. I have used it to display my favorite video.

header:
    The <header> tag in HTML serves as a defining element for the header of a document or a section, encapsulating information pertinent to the title and heading of the associated content. I have used it to display my menu and name.

footer:
    The <footer> tag in HTML is used to define the footer section of an HTML document. This section typically contains information such as authorship information, copyright information, contact information, sitemap, back-to-top links, related documents, etc.

summary:
    The HTML <summary> tag defines a summary for the <details> element. The <summary> tag is used along with the <details> element and provides a summary visible to the user. When the user clicks the summary, the content placed inside the <details> element becomes visible which was previously hidden. I have used it to display my work experience.

menu:
    HTML <menu> Tag defines an Unordered List of items. For creating an unordered list, we can use the <menu> tag with HTML <li> tags. The HTML <menu> tag is a semantic tag and an alternative option for the HTML <ul> tag. I have used it to display content of the website.

tel for contact information:
    HTML provides browsers with protocols such as tel which are used to add clickable phone numbers. Every browser responds differently to these protocols. We can use it in <a> tag. I have used it to display my phone number.

mailto for contact information: 
    The mailto link in HTML is a convenient method for users to send emails. It triggers the default email client with pre-filled recipient, subject, body, CC, and BCC fields, often used for feedback forms or direct communication. We can use it in <a> tag. I have used it to display my email address.